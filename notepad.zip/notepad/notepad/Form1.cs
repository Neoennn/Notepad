using System;
using System.Data;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace MySQLNotepad
{
    public partial class Form1 : Form
    {
        private string connectionString = "Server=localhost;Database=notepad_db;Uid=root;Pwd=;";

        public Form1()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            LoadNotes();
        }

        private void LoadNotes()
        {
            try
            {
                using (var connection = new MySqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT * FROM Notes";
                    using (var adapter = new MySqlDataAdapter(query, connection))
                    {
                        DataTable table = new DataTable();
                        adapter.Fill(table);
                        dgvNotes.DataSource = table;
                    }
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtTitle.Text) || string.IsNullOrWhiteSpace(rtbContent.Text))
            {
                MessageBox.Show("Title and content cannot be empty!");
                return;
            }

            try
            {
                using (var connection = new MySqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "INSERT INTO Notes (Title, Content) VALUES (@title, @content)";
                    using (var command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@title", txtTitle.Text);
                        command.Parameters.AddWithValue("@content", rtbContent.Text);
                        command.ExecuteNonQuery();
                    }
                }
                MessageBox.Show("Catatan berhasil disimpan!");
                LoadNotes();
                ClearFields();
            }
            catch (MySqlException ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (dgvNotes.CurrentRow == null)
            {
                MessageBox.Show("Please select a note to update!");
                return;
            }

            int id = Convert.ToInt32(dgvNotes.CurrentRow.Cells["Id"].Value);

            try
            {
                using (var connection = new MySqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "UPDATE Notes SET Title = @title, Content = @content WHERE Id = @id";
                    using (var command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@title", txtTitle.Text);
                        command.Parameters.AddWithValue("@content", rtbContent.Text);
                        command.Parameters.AddWithValue("@id", id);
                        command.ExecuteNonQuery();
                    }
                }
                MessageBox.Show("Catatan berhasil diperbarui!");
                LoadNotes();
                ClearFields();
            }
            catch (MySqlException ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dgvNotes.CurrentRow == null)
            {
                MessageBox.Show("Please select a note to delete!");
                return;
            }

            int id = Convert.ToInt32(dgvNotes.CurrentRow.Cells["Id"].Value);

            try
            {
                using (var connection = new MySqlConnection(connectionString))
                {
                    connection.Open();

                    // Hapus catatan berdasarkan ID
                    string query = "DELETE FROM Notes WHERE Id = @id";
                    using (var command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@id", id);
                        command.ExecuteNonQuery();
                    }

                    // Jika tabel kosong, reset AUTO_INCREMENT
                    string resetQuery = "SELECT COUNT(*) FROM Notes";
                    using (var command = new MySqlCommand(resetQuery, connection))
                    {
                        int count = Convert.ToInt32(command.ExecuteScalar());
                        if (count == 0) // Jika tabel kosong
                        {
                            string alterQuery = "ALTER TABLE Notes AUTO_INCREMENT = 1";
                            using (var alterCommand = new MySqlCommand(alterQuery, connection))
                            {
                                alterCommand.ExecuteNonQuery();
                            }
                        }
                    }
                }
                MessageBox.Show("Catatan berhasil dihapus!");
                LoadNotes();
                ClearFields();
            }
            catch (MySqlException ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void dgvNotes_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                txtTitle.Text = dgvNotes.Rows[e.RowIndex].Cells["Title"].Value.ToString();
                rtbContent.Text = dgvNotes.Rows[e.RowIndex].Cells["Content"].Value.ToString();
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            dgvNotes.DataSource = " ";
        }

        private void ClearFields()
        {
            txtTitle.Clear();
            rtbContent.Clear();
           
        }
    }
}
